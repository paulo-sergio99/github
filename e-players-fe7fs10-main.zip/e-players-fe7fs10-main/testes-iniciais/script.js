function saudarUsuarios() {
    alert("Boa noite pessoal, sejam bem vindos!!!");
}